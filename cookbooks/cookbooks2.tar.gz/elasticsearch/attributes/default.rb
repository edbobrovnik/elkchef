# Attributes are set to no-functional values.
# Real values should come from attributes set in environments.

default["elasticsearch"]["networkhost"] = "192.192.192.192"
default["elasticsearch"]["envname"] = "PLACEHOLDER"
