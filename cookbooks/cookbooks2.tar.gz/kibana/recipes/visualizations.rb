#
# Cookbook Name:: kibana
# Recipe:: visualizations
#
# Copyright (c) 2016 The Authors, All Rights Reserved.
