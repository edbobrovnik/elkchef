#
# Cookbook Name:: kibana
# Recipe:: dashboards
#
# Copyright (c) 2016 The Authors, All Rights Reserved.
