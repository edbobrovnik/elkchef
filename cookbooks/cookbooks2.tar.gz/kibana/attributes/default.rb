
default["kibana"]["kibanatempdir"] = Chef::Config[:file_cache_path] + '/kibanatempdir' 
